"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
var wi_contrib_1 = require("wi-studio/app/contrib/wi-contrib");
var contrib_1 = require("wi-studio/common/models/contrib");
var lodash = require("lodash");
var oldSchema;
var mutationFields = [];
var queryFields = [];
var operationTypes = [
    {
        "unique_id": "Query",
        "name": "Query"
    },
    {
        "unique_id": "Mutation",
        "name": "Mutation"
    }
];
var emptyArray = [];
var graphqlHandler = (function (_super) {
    __extends(graphqlHandler, _super);
    function graphqlHandler(injector, http, contribModelService) {
        var _this = _super.call(this, injector, http, contribModelService) || this;
        _this.injector = injector;
        _this.http = http;
        _this.contribModelService = contribModelService;
        _this.value = function (fieldName, context) {
            var operation = context.getField("operation").value;
            var schema = context.getField("graphqlSchema").value;
            switch (fieldName) {
                case "resolverFor":
                    if (operation && schema && operation != "" && schema != "") {
                        if (oldSchema != schema) {
                            return Observable_1.Observable.create(function (observer) {
                                wi_contrib_1.WiContributionUtils.parseGraphqlSchema(_this.http, schema)
                                    .subscribe(function (gqlResult) {
                                    if (gqlResult.success) {
                                        oldSchema = schema;
                                        mutationFields.length = 0;
                                        queryFields.length = 0;
                                        gqlResult.flows.map(function (flow) {
                                            if (flow.type === "Query") {
                                                queryFields.push(flow.name);
                                            }
                                            else {
                                                mutationFields.push(flow.name);
                                            }
                                        });
                                        if (operation === "Query") {
                                            observer.next(queryFields);
                                        }
                                        else {
                                            observer.next(mutationFields);
                                        }
                                    }
                                    else {
                                        return observer.next(null);
                                    }
                                }, function (err) {
                                    observer.next(null);
                                }, function () {
                                    observer.complete();
                                });
                            });
                        }
                        else {
                            if (operation === "Query") {
                                return queryFields;
                            }
                            else {
                                return mutationFields;
                            }
                        }
                    }
                    return null;
                case "operation":
                    if (schema && schema != "") {
                        return operationTypes;
                    }
                    else {
                        return emptyArray;
                    }
                default:
                    return null;
            }
        };
        _this.validate = function (fieldName, context) {
            if (fieldName === "path") {
                if (context.getMode() === contrib_1.MODE.SERVERLESS_FLOW || context.getMode() === contrib_1.MODE.UPLOAD) {
                    var path = context.getField("path");
                    if (!_this.verifyPathStartSlash(path.value)) {
                        return wi_contrib_1.ValidationResult.newValidationResult().setError("PATH_ERROR", "Path required and should start with \"/\" like \"/graphql\"");
                    }
                }
            }
            else if (fieldName === "port") {
                return wi_contrib_1.ValidationResult.newValidationResult().setVisible(true);
            }
            else if (fieldName === "secureConnection") {
                return Observable_1.Observable.create(function (observer) {
                    wi_contrib_1.WiContributionUtils.getAppConfig(_this.http)
                        .subscribe(function (data) {
                        if (data.deployment === wi_contrib_1.APP_DEPLOYMENT.ON_PREMISE) {
                            observer.next(wi_contrib_1.ValidationResult.newValidationResult().setVisible(true));
                        }
                        else {
                            observer.next(wi_contrib_1.ValidationResult.newValidationResult().setVisible(false));
                        }
                    }, function (err) {
                        observer.next(wi_contrib_1.ValidationResult.newValidationResult().setVisible(false));
                    }, function () { return observer.complete(); });
                });
            }
            else if (fieldName === "operation") {
                if (context.getMode() === contrib_1.MODE.SERVERLESS_FLOW) {
                    return wi_contrib_1.ValidationResult.newValidationResult().setReadOnly(false);
                }
                else {
                    return wi_contrib_1.ValidationResult.newValidationResult().setReadOnly(true);
                }
            }
            else if (fieldName === "graphqlSchema") {
                if (context.getMode() === contrib_1.MODE.SERVERLESS_FLOW || context.getMode() === contrib_1.MODE.UPLOAD) {
                    return wi_contrib_1.ValidationResult.newValidationResult().setVisible(true);
                }
                else {
                    return wi_contrib_1.ValidationResult.newValidationResult().setVisible(false);
                }
            }
            else if (fieldName === "resolverFor") {
                if (context.getMode() === contrib_1.MODE.SERVERLESS_FLOW) {
                    return wi_contrib_1.ValidationResult.newValidationResult().setReadOnly(false);
                }
                else {
                    return wi_contrib_1.ValidationResult.newValidationResult().setReadOnly(true);
                }
            }
            else if (fieldName === "serverKey" || fieldName === "caCertificate") {
                var secure = context.getField("secureConnection");
                if (secure.value == true) {
                    return wi_contrib_1.ValidationResult.newValidationResult().setVisible(true);
                }
                else {
                    return wi_contrib_1.ValidationResult.newValidationResult().setVisible(false);
                }
            }
            return null;
        };
        _this.action = function (actionId, context) {
            var modelService = _this.getModelService();
            var result = wi_contrib_1.CreateFlowActionResult.newActionResult();
            var actionResult = wi_contrib_1.ActionResult.newActionResult();
            var schema = context.getField("graphqlSchema").value;
            var flowList = [];
            return Observable_1.Observable.create(function (observer) {
                wi_contrib_1.WiContributionUtils.parseGraphqlSchema(_this.http, schema)
                    .subscribe(function (gqlResult) {
                    if (gqlResult.success === false) {
                        actionResult.setSuccess(false);
                        actionResult.setResult(wi_contrib_1.ValidationResult.newValidationResult().setError("GraphQLError", gqlResult.error));
                        observer.next(actionResult);
                    }
                    else {
                        flowList = gqlResult.flows;
                        if (context.getMode() === contrib_1.MODE.SERVERLESS_FLOW) {
                            var wOperation_1 = context.getField("operation");
                            var wResolverFor_1 = context.getField("resolverFor");
                            var wPort_1 = context.getField("port");
                            var wPath_1 = context.getField("path");
                            var wSchema_1 = context.getField("graphqlSchema");
                            var wSecureConnection_1 = context.getField("secureConnection");
                            var wServerKey_1 = context.getField("serverKey");
                            var wCACertificate_1 = context.getField("caCertificate");
                            var trigger = modelService.createTriggerElement("Default/tibco-graphql");
                            if (trigger && trigger.settings && trigger.settings.length > 0) {
                                trigger.settings.map(function (setting) {
                                    if (setting.name === "path") {
                                        setting.value = wPath_1.value;
                                    }
                                    else if (setting.name === "port") {
                                        setting.value = wPort_1.value;
                                    }
                                    else if (setting.name === "graphqlSchema") {
                                        setting.value = wSchema_1.value;
                                    }
                                    else if (setting.name === "secureConnection") {
                                        setting.value = wSecureConnection_1.value;
                                    }
                                    else if (setting.name === "serverKey") {
                                        setting.value = wServerKey_1.value;
                                    }
                                    else if (setting.name === "caCertificate") {
                                        setting.value = wCACertificate_1.value;
                                    }
                                });
                            }
                            if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                                trigger.handler.settings.map(function (hndlrSetting) {
                                    if (hndlrSetting.name === "operation") {
                                        hndlrSetting.value = wOperation_1.value;
                                    }
                                    else if (hndlrSetting.name === "resolverFor") {
                                        hndlrSetting.value = wResolverFor_1.value;
                                    }
                                });
                            }
                            if (trigger && trigger.outputs && trigger.outputs.length > 0) {
                                for (var j = 0; j < trigger.outputs.length; j++) {
                                    if (trigger.outputs[j].name === "arguments") {
                                        for (var i = 0; i < flowList.length; i++) {
                                            if (flowList[i].type === wOperation_1.value && flowList[i].name === wResolverFor_1.value) {
                                                trigger.outputs[j].value = flowList[i].inputs;
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            if (trigger && trigger.reply && trigger.reply.length > 0) {
                                for (var j = 0; j < trigger.reply.length; j++) {
                                    if (trigger.reply[j].name === "data") {
                                        for (var i = 0; i < flowList.length; i++) {
                                            if (flowList[i].type === wOperation_1.value && flowList[i].name === wResolverFor_1.value) {
                                                trigger.reply[j].value = flowList[i].outputs;
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            _this.doTriggerMapping(trigger);
                            var dummyFlowModel = modelService.createFlow(context.getFlowName(), context.getFlowDescription(), false);
                            result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(dummyFlowModel));
                        }
                        else if (context.getMode() === contrib_1.MODE.UPLOAD) {
                            flowList.map(function (flow) {
                                var trigger = modelService.createTriggerElement("Default/tibco-graphql");
                                if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                                    trigger.handler.settings.map(function (hndlrSetting) {
                                        if (hndlrSetting.name === "operation") {
                                            hndlrSetting.value = flow.type;
                                        }
                                        else if (hndlrSetting.name === "resolverFor") {
                                            hndlrSetting.value = flow.name;
                                        }
                                    });
                                }
                                if (trigger && trigger.outputs && trigger.outputs.length > 0) {
                                    if (trigger.outputs[0].name === "arguments") {
                                        trigger.outputs[0].value = flow.inputs;
                                    }
                                }
                                if (trigger && trigger.reply && trigger.reply.length > 0) {
                                    if (trigger.reply[0].name === "data") {
                                        trigger.reply[0].value = flow.outputs;
                                    }
                                }
                                _this.doTriggerMapping(trigger);
                                var flowModel = modelService.createFlow(flow.type + "_" + flow.name, flow.description, false);
                                var returnAct = modelService.createFlowElement("Default/flogo-return");
                                var uploadFlow = flowModel.addFlowElement(returnAct);
                                result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(uploadFlow));
                            });
                        }
                        actionResult.setSuccess(true).setResult(result);
                        observer.next(actionResult);
                    }
                }, function (err) {
                    observer.next(null);
                }, function () { return observer.complete(); });
            });
        };
        return _this;
    }
    graphqlHandler.prototype.doTriggerMapping = function (trigger) {
        var outputMappingElement = this.contribModelService.createMapping();
        var outputexpr = this.contribModelService.createMapExpression();
        outputMappingElement.addMapping("$INPUT['" + trigger.outputs[0].name + "']", outputexpr.setExpression("$trigger." + trigger.outputs[0].name));
        trigger.inputMappings = outputMappingElement;
        var replyMappingElement = this.contribModelService.createMapping();
        var replyexpr = this.contribModelService.createMapExpression();
        replyMappingElement.addMapping("$INPUT['" + trigger.reply[0].name + "']", replyexpr.setExpression("$flow." + trigger.reply[0].name));
        trigger.outputMappings = replyMappingElement;
    };
    graphqlHandler.prototype.verifyPathStartSlash = function (path) {
        var regexPathSlash = /(?:(?:^\/){1}(?:[-a-zA-Z0-9_]+)){1}(?:(?:(?:[\/]{1})(?:(?:(?:[\{]{1})(?:[-a-zA-Z0-9_\:]+)(?:[\}]{1}))|(?:[-a-zA-Z0-9_\:]+)))*)$/i;
        var result = regexPathSlash.test(path);
        return result;
    };
    graphqlHandler = __decorate([
        wi_contrib_1.WiContrib({}),
        core_1.Injectable(),
        __metadata("design:paramtypes", [core_1.Injector, http_1.Http, wi_contrib_1.WiContribModelService])
    ], graphqlHandler);
    return graphqlHandler;
}(wi_contrib_1.WiServiceHandlerContribution));
exports.graphqlHandler = graphqlHandler;
//# sourceMappingURL=graphqlHandler.js.map