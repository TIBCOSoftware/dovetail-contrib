import { Injectable, Injector } from "@angular/core";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import {
    WiContrib,
    WiServiceHandlerContribution,
    IValidationResult,
    ValidationResult,
    ActionResult,
    IActionResult,
    WiContribModelService,
    WiContributionUtils,
    CreateFlowActionResult,
    APP_DEPLOYMENT
} from "wi-studio/app/contrib/wi-contrib";
import { ITriggerContribution, IFieldDefinition, MODE, ICreateFlowActionContext, IGraphqlFlow, ITriggerElement } from "wi-studio/common/models/contrib";
import * as lodash from "lodash";

let oldSchema: string;
let mutationFields: string[] = [];
let queryFields: string[] = [];

const operationTypes = [
    {
        "unique_id": "Query",
        "name": "Query"
    },
    {
        "unique_id": "Mutation",
        "name": "Mutation"
    }
];

const emptyArray = [];

@WiContrib({})
@Injectable()
export class graphqlHandler extends WiServiceHandlerContribution {

    constructor(private injector: Injector, private http: Http, private contribModelService: WiContribModelService) {
        super(injector, http, contribModelService);
    }

    value = (fieldName: string, context: ITriggerContribution): Observable<any> | any => {
        let operation: string = context.getField("operation").value;
        let schema: string = context.getField("graphqlSchema").value;
        switch (fieldName) {
            case "resolverFor":
                if (operation && schema && operation != "" && schema != "") {
                    if (oldSchema != schema) {
                        // call parse only if there is change in schema
                        return Observable.create(observer => {
                            WiContributionUtils.parseGraphqlSchema(this.http, schema)
                                .subscribe(gqlResult => {
                                    if (gqlResult.success) {
                                        oldSchema = schema;
                                        mutationFields.length = 0;
                                        queryFields.length = 0;
                                        gqlResult.flows.map(flow => {
                                            if (flow.type === "Query") {
                                                queryFields.push(flow.name);
                                            } else {
                                                mutationFields.push(flow.name);
                                            }
                                        });
                                        if (operation === "Query") {
                                            observer.next(queryFields);
                                        } else {
                                            observer.next(mutationFields);
                                        }
                                    } else {
                                        return observer.next(null);
                                    }
                                }, err => {
                                    observer.next(null);
                                }, () => {
                                    observer.complete()
                                });
                        });
                    } else {
                        if (operation === "Query") {
                            return queryFields;
                        } else {
                            return mutationFields;
                        }
                    }
                }
                return null;
            case "operation":
                if (schema && schema != "") {
                    return operationTypes;
                } else {
                    return emptyArray;
                }
            default:
                return null;
        }
    }

    validate = (fieldName: string, context: ITriggerContribution): Observable<IValidationResult> | IValidationResult => {
        if (fieldName === "path") {
            if (context.getMode() === MODE.SERVERLESS_FLOW || context.getMode() === MODE.UPLOAD) {
                let path: IFieldDefinition = context.getField("path");
                if (!this.verifyPathStartSlash(path.value)) {
                    return ValidationResult.newValidationResult().setError("PATH_ERROR", "Path required and should start with \"/\" like \"/graphql\"");
                }
            }
        } else if (fieldName === "port") {
            // required to fix upgrade scenario for FLOGO-3640
            return ValidationResult.newValidationResult().setVisible(true);
        } else if (fieldName === "secureConnection") {
            return Observable.create(observer => {
                WiContributionUtils.getAppConfig(this.http)
                    .subscribe(data => {
                        if (data.deployment === APP_DEPLOYMENT.ON_PREMISE) {
                            observer.next(ValidationResult.newValidationResult().setVisible(true));
                        } else {
                            observer.next(ValidationResult.newValidationResult().setVisible(false));
                        }
                    }, err => {
                        observer.next(ValidationResult.newValidationResult().setVisible(false));
                    }, () => observer.complete());
            });
        } else if (fieldName === "operation") {
            if (context.getMode() === MODE.SERVERLESS_FLOW) {
                // Create trigger from wizard - allow selecting operation type
                return ValidationResult.newValidationResult().setReadOnly(false);
            } else {
                // Operation type cannot be changed
                return ValidationResult.newValidationResult().setReadOnly(true);
            }
        } else if (fieldName === "graphqlSchema") {
            if (context.getMode() === MODE.SERVERLESS_FLOW || context.getMode() === MODE.UPLOAD) {
                // throw warning for Directives, input type, and scalar
                return ValidationResult.newValidationResult().setVisible(true);
            } else {
                // set visibility to false
                return ValidationResult.newValidationResult().setVisible(false);
            }
        } else if (fieldName === "resolverFor") {
            if (context.getMode() === MODE.SERVERLESS_FLOW) {
                // ResolverFor can be selected from drop-down in wizard
                return ValidationResult.newValidationResult().setReadOnly(false);
            } else {
                // ResolverFor cannot be changed
                return ValidationResult.newValidationResult().setReadOnly(true);
            }
        } else if (fieldName === "serverKey" || fieldName === "caCertificate") {
            let secure: IFieldDefinition = context.getField("secureConnection");
            if (secure.value == true) {
                return ValidationResult.newValidationResult().setVisible(true);
            } else {
                return ValidationResult.newValidationResult().setVisible(false);
            }
        }
        return null;
    }

    action = (actionId: string, context: ICreateFlowActionContext): Observable<IActionResult> | IActionResult => {
        let modelService = this.getModelService();
        let result = CreateFlowActionResult.newActionResult();
        let actionResult = ActionResult.newActionResult();
        let schema: string = context.getField("graphqlSchema").value;
        let flowList: IGraphqlFlow[] = [];
        return Observable.create(observer => {
            // Parse the schema
            WiContributionUtils.parseGraphqlSchema(this.http, schema)
                .subscribe(gqlResult => {
                    if (gqlResult.success === false) {
                        // validation error
                        actionResult.setSuccess(false);
                        actionResult.setResult(ValidationResult.newValidationResult().setError("GraphQLError", gqlResult.error));
                        observer.next(actionResult);
                    } else {
                        // success case, get flows from parse Result
                        flowList = gqlResult.flows;

                        if (context.getMode() === MODE.SERVERLESS_FLOW) {
                            // get values from wizard
                            let wOperation = <IFieldDefinition>context.getField("operation");
                            let wResolverFor = <IFieldDefinition>context.getField("resolverFor");
                            let wPort = <IFieldDefinition>context.getField("port");
                            let wPath = <IFieldDefinition>context.getField("path");
                            let wSchema = <IFieldDefinition>context.getField("graphqlSchema");
                            let wSecureConnection = <IFieldDefinition>context.getField("secureConnection");
                            let wServerKey = <IFieldDefinition>context.getField("serverKey");
                            let wCACertificate = <IFieldDefinition>context.getField("caCertificate");

                            // create trigger
                            let trigger = modelService.createTriggerElement("Default/tibco-graphql");

                            // copy values from trigger wizard into trigger
                            if (trigger && trigger.settings && trigger.settings.length > 0) {
                                // set all trigger settings -- use default values if no value provided
                                trigger.settings.map(setting => {
                                    if (setting.name === "path") {
                                        setting.value = wPath.value;
                                    } else if (setting.name === "port") {
                                        setting.value = wPort.value;
                                    } else if (setting.name === "graphqlSchema") {
                                        setting.value = wSchema.value;
                                    } else if (setting.name === "secureConnection") {
                                        setting.value = wSecureConnection.value;
                                    } else if (setting.name === "serverKey") {
                                        setting.value = wServerKey.value;
                                    } else if (setting.name === "caCertificate") {
                                        setting.value = wCACertificate.value;
                                    }
                                });
                            }

                            if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                                // set operation and resolverFor on handler
                                trigger.handler.settings.map(hndlrSetting => {
                                    if (hndlrSetting.name === "operation") {
                                        hndlrSetting.value = wOperation.value;
                                    } else if (hndlrSetting.name === "resolverFor") {
                                        hndlrSetting.value = wResolverFor.value;
                                    }
                                });
                            }
                            if (trigger && trigger.outputs && trigger.outputs.length > 0) {
                                // set trigger output
                                for (let j = 0; j < trigger.outputs.length; j++) {
                                    if (trigger.outputs[j].name === "arguments") {
                                        for (let i = 0; i < flowList.length; i++) {
                                            // find the graphql flow(query field or mutation field) that matches operation and resolverFor
                                            if (flowList[i].type === wOperation.value && flowList[i].name === wResolverFor.value) {
                                                trigger.outputs[j].value = flowList[i].inputs;
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                            }

                            if (trigger && trigger.reply && trigger.reply.length > 0) {
                                // set trigger reply
                                for (let j = 0; j < trigger.reply.length; j++) {
                                    if (trigger.reply[j].name === "data") {
                                        for (let i = 0; i < flowList.length; i++) {
                                            // find the graphql flow(query field or mutation field) that matches operation and resolverFor
                                            if (flowList[i].type === wOperation.value && flowList[i].name === wResolverFor.value) {
                                                trigger.reply[j].value = flowList[i].outputs;
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                            }

                            // map trigger output to flow input and flow output to trigger reply
                            this.doTriggerMapping(trigger)

                            let dummyFlowModel = modelService.createFlow(context.getFlowName(), context.getFlowDescription(), false);

                            result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(dummyFlowModel));
                        } else if (context.getMode() === MODE.UPLOAD) {
                            // create a flow and trigger for each query and mutation field
                            flowList.map(flow => {
                                // create trigger
                                let trigger = modelService.createTriggerElement("Default/tibco-graphql");

                                // use default values for settings from trigger.json
                                if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                                    // set operation and resolverFor on handler
                                    trigger.handler.settings.map(hndlrSetting => {
                                        if (hndlrSetting.name === "operation") {
                                            hndlrSetting.value = flow.type;
                                        } else if (hndlrSetting.name === "resolverFor") {
                                            hndlrSetting.value = flow.name;
                                        }
                                    });
                                }

                                // copy flow input schema to trigger output
                                if (trigger && trigger.outputs && trigger.outputs.length > 0) {
                                    if (trigger.outputs[0].name === "arguments") {
                                        trigger.outputs[0].value = flow.inputs;
                                    }
                                }

                                // copy flow output schema to trigger reply
                                if (trigger && trigger.reply && trigger.reply.length > 0) {
                                    if (trigger.reply[0].name === "data") {
                                        trigger.reply[0].value = flow.outputs;
                                    }
                                }

                                // map trigger output to flow input and flow output to trigger reply for each flow
                                this.doTriggerMapping(trigger);

                                let flowModel = modelService.createFlow(flow.type + "_" + flow.name, flow.description, false);

                                // add return activity
                                let returnAct = modelService.createFlowElement("Default/flogo-return");
                                let uploadFlow = flowModel.addFlowElement(returnAct);
                                result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(uploadFlow));
                            });
                        }
                        actionResult.setSuccess(true).setResult(result);
                        observer.next(actionResult);
                    }
                }, err => {
                    observer.next(null);
                }, () => observer.complete());
        });
    }

    doTriggerMapping(trigger: ITriggerElement) {
        let outputMappingElement = this.contribModelService.createMapping();
        let outputexpr = this.contribModelService.createMapExpression();
        outputMappingElement.addMapping("$INPUT['" + trigger.outputs[0].name + "']", outputexpr.setExpression("$trigger." + trigger.outputs[0].name));
        (<any>trigger).inputMappings = outputMappingElement;

        let replyMappingElement = this.contribModelService.createMapping();
        let replyexpr = this.contribModelService.createMapExpression();
        replyMappingElement.addMapping("$INPUT['" + trigger.reply[0].name + "']", replyexpr.setExpression("$flow." + trigger.reply[0].name));
        (<any>trigger).outputMappings = replyMappingElement;
    }

    verifyPathStartSlash(path: string): boolean {
        let regexPathSlash = /(?:(?:^\/){1}(?:[-a-zA-Z0-9_]+)){1}(?:(?:(?:[\/]{1})(?:(?:(?:[\{]{1})(?:[-a-zA-Z0-9_\:]+)(?:[\}]{1}))|(?:[-a-zA-Z0-9_\:]+)))*)$/i;
        let result = regexPathSlash.test(path);
        return result;
    }
}